# @noble-collective/userdata

The shared user-data contract for the Noble Collective ecosystem — the layer the resources website,
Coram Deo, the Institute and the Flutter app (via its Dart port) all agree on so per-user data,
settings and sign-in are consistent across products. Full design: `../../ARCHITECTURE.md`.

## What's here

**Ring 1 — pure core** (`src/core/`, no I/O):
- `anchor.ts` — renderer-independent text anchoring (`normalize` / `computeAnchor` / `resolveAnchor`).
  Highlights survive the typographer/whitespace/edit-drift differences between the Flutter,
  markdown-it, and ReactMarkdown renderers by anchoring against normalized **source** text.
- `osis.ts` — canonical 66-book OSIS ⇄ Coram Deo integer `verseId` addressing.
- `locator.ts` — the universal `Locator` (series / bible / catena) + builders + deterministic
  `answerDocId` (scoped by book+session+question).
- `schema.ts` — zod validators for all five document types (client-side twin of the Firestore rules).
- `constants.ts` — collections, corpora, annotation kinds, colors, translations.
- `settings.ts` — the canonical cross-product settings object + no-clobber merge.
- `auth-contract.ts` — the sign-in rules every product follows: Google→Apple button order and labels,
  `SIGN_IN_BENEFIT` (the app's line), the dialog copy (link, name prompt, combine, remove, Connected
  accounts, `SIGN_IN_ERRORS`), `canUnlink`, `reauthKindFor`, `isRelayEmail`,
  and `trustedEmail(decodedToken)` (authz may only trust a verified primary email).
- `session-identity.ts` — `sessionIdentity(claims, clientProfile?)` for session endpoints: uid,
  `trustedEmail`, a bounded display name (a client name only fills a gap), photo. Also built standalone
  (`/session-identity`, no zod) so servers that can't load the SDK can vendor the CJS.

**Security rules** (`rules/firestore.rules`) — lock `users/{uid}/**` to the owner + shape validation
mirroring the zod schemas.

**Ring 2 — adapters:**
- `client/` — `createUserDataClient(db, uid)` over the Firestore web SDK, incl. live `on*`
  subscriptions and `onSettingsRaw`.
- `server/` — `createUserDataServer(db, uid)` over firebase-admin (API routes, migrations).
- `auth/` — sign-in over `firebase/auth` for the web products: `signIn` (Google/Apple; returns
  signed-in / needs-link / cancelled / popup-blocked), `completeLink` (wrong-account guard),
  `linkProvider` / `unlinkProvider` (never the last), `reauth`, profile backfill, `setDisplayName`,
  `requestEmailChange`. Each flow takes an `authenticate` hook (default popup) so tests can use
  credentials against the Auth emulator.
- `signin/` — **the web sign-in kit** (`/signin`, `/signin/react`): one framework-free controller with
  the page / compact / sheet panels, the four dialogs, Connected accounts, popup → redirect fallback,
  combine accounts and `reauthForDelete`, themed with `--si-*` tokens (`THEMES` presets). Each site
  passes its own `copy.benefit`. See ARCHITECTURE §9a.8.

```ts
import { createSignIn } from '@noble-collective/userdata/signin'
const signIn = createSignIn({
  auth,                                          // the site's own Firebase Auth
  providers: appleOn ? ['google', 'apple'] : ['google'],
  bridgeSession: (user, profile) => postSession(user, profile), // throw { code: 'email-not-verified' } on 403
  returnTo: { href: '/b/call/3', label: 'The Call of Christ · Session 3' },
  copy: { benefit: 'Sign in to pick up any book where you left off…', eyebrow: 'Noble Imprint Resources' },
})
signIn.mountPanel(document.querySelector('#signin')!, { variant: 'page' })
signIn.mountConnectedAccounts(document.querySelector('#accounts')!)
if ((await signIn.reauthForDelete()) === 'cancelled') return
```

React: `const { controller } = useSignIn(opts)`, then `<SignInPanel signIn={controller} variant="compact" />`
and `<ConnectedAccounts signIn={controller} />`.

## Scripts

```bash
npm test            # pure unit tests (anchor / locator / schema) — no emulator needed
npm run test:rules  # Firestore security-rules tests — REQUIRES the emulator + Java (see below)
npm run test:auth   # Auth-emulator sign-in / linking flow tests — REQUIRES Java (same setup)
npm run build       # dual ESM + CJS + .d.ts via tsup
npm run typecheck   # tsc --noEmit
npm run demo:signin # the sign-in kit: three skins + dialog scenarios on http://localhost:5178 (Auth emulator)
```

## Consuming (GitHub Packages)

Published privately to GitHub Packages on each GitHub Release (`.github/workflows/publish.yml`).
A consuming repo adds a scoped registry in `.npmrc`:

```
@noble-collective:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

then `npm install @noble-collective/userdata`. In Docker/CI builds, `NODE_AUTH_TOKEN` must be a token
with `read:packages`. In practice the web products vendor a tarball instead (`npm pack` here → copy
to the consumer's `vendor/` → `npm install ./vendor/<tgz>` explicitly, since a same-name tarball won't
refresh). Entry points: `@noble-collective/userdata` (core), `/core`, `/client` (Firestore web SDK),
`/server` (firebase-admin), `/auth` (firebase/auth sign-in), `/signin` + `/signin/react` (the web
sign-in kit; React is an optional peer), `/session-identity` (standalone CJS for servers). `firebase` / `firebase-admin` are optional peer deps — the consumer
brings whichever it needs.

## Running the rules tests

`test:rules` wraps the suite in `firebase emulators:exec`, which needs a JRE (11+). Install once
(e.g. `winget install Microsoft.OpenJDK.21`) and ensure `java` is on `PATH`. The first run downloads
the Firestore emulator jar. The pure `npm test` suite needs neither Java nor the emulator, so CI can
run it without extra setup.
