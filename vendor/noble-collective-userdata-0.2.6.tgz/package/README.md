# @noble-collective/userdata

The shared user-data contract for the Noble Collective ecosystem — the layer the resource website,
Coram Deo, and (later) the Flutter app all agree on so per-user data is consistent across products.

## What's here

**Ring 1 — pure core** (`src/core/`, no I/O):
- `anchor.ts` — renderer-independent text anchoring (`normalize` / `computeAnchor` / `resolveAnchor`).
  Highlights survive the typographer/whitespace/edit-drift differences between the Flutter,
  markdown-it, and ReactMarkdown renderers by anchoring against normalized **source** text.
- `osis.ts` — canonical 66-book OSIS ⇄ Coram Deo integer `verseId` addressing.
- `locator.ts` — the universal `Locator` (series / bible / catena) + builders + deterministic
  `answerDocId` (scoped by book+session+question).
- `schema.ts` — zod validators for all five document types (client-side twin of the Firestore rules).
- `constants.ts` — collections, corpora, annotation kinds, colors, translations.

**Security rules** (`rules/firestore.rules`) — lock `users/{uid}/**` to the owner + shape validation
mirroring the zod schemas.

Rings 2 (client + server Firestore SDK adapters) are next.

## Scripts

```bash
npm test            # pure unit tests (anchor / locator / schema) — no emulator needed
npm run test:rules  # Firestore security-rules tests — REQUIRES the emulator + Java (see below)
npm run build       # dual ESM + CJS + .d.ts via tsup
npm run typecheck   # tsc --noEmit
```

## Consuming (GitHub Packages)

Published privately to GitHub Packages on each GitHub Release (`.github/workflows/publish.yml`).
A consuming repo adds a scoped registry in `.npmrc`:

```
@noble-collective:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

then `npm install @noble-collective/userdata`. In Docker/CI builds, `NODE_AUTH_TOKEN` must be a token
with `read:packages`. Entry points: `@noble-collective/userdata` (core), `/client` (Firestore web
SDK), `/server` (firebase-admin). `firebase` / `firebase-admin` are optional peer deps — the consumer
brings whichever it needs.

## Running the rules tests

`test:rules` wraps the suite in `firebase emulators:exec`, which needs a JRE (11+). Install once
(e.g. `winget install Microsoft.OpenJDK.21`) and ensure `java` is on `PATH`. The first run downloads
the Firestore emulator jar. The pure `npm test` suite needs neither Java nor the emulator, so CI can
run it without extra setup.
